#ifndef _STUDENT_H 
#define _STUDENT_H

class Student{
	private:
		char mssv[11];
		char name[31];
		float averMark;
	public:
		void input();
		void print();
};

#endif
