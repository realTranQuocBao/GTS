#include "Student.h"

int main(){
	Student bg;
	bg.input();
	bg.print();
	return 0;
}
